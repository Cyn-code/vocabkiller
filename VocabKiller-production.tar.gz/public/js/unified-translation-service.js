// Unified Translation Service for VocabKiller
// Implements the new translation strategy across all pages

class UnifiedTranslationService {
    constructor() {
        // API endpoints
        this.freeDictionaryUrl = 'https://api.dictionaryapi.dev/api/v2/entries/en';
        this.googleTranslateUrl = 'https://translate.googleapis.com/translate_a/single';
        this.myMemoryUrl = 'https://api.mymemory.translated.net/get';
        
        // Cache for translations
        this.vocabularyCache = new Map();
        this.sentenceCache = new Map();
        this.definitionCache = new Map();
        this.maxCacheSize = 200;
        
        // Initialize common word translations
        this.initializeCommonWords();
    }

    // Initialize common word translations for offline use
    initializeCommonWords() {
        const commonWords = {
            'hello': '你好',
            'world': '世界',
            'good': '好的',
            'bad': '坏的',
            'big': '大的',
            'small': '小的',
            'fast': '快的',
            'slow': '慢的',
            'new': '新的',
            'old': '旧的',
            'yes': '是的',
            'no': '不',
            'please': '请',
            'thank': '谢谢',
            'sorry': '对不起',
            'help': '帮助',
            'time': '时间',
            'day': '天',
            'night': '夜晚',
            'morning': '早上',
            'afternoon': '下午',
            'evening': '晚上'
        };

        Object.entries(commonWords).forEach(([word, translation]) => {
            this.vocabularyCache.set(`${word}_zh`, {
                translation: translation,
                source: 'offline-cache',
                definition: null
            });
        });
    }

    // Manage cache size
    manageCacheSize(cache) {
        if (cache.size > this.maxCacheSize) {
            const entriesToRemove = Math.floor(this.maxCacheSize * 0.2);
            const keys = Array.from(cache.keys()).slice(0, entriesToRemove);
            keys.forEach(key => cache.delete(key));
        }
    }

    // VOCABULARY TRANSLATION: Free Dictionary API → Google Translate → MyMemory
    async translateVocabulary(word, targetLang = 'zh') {
        const cacheKey = `${word}_${targetLang}`;
        
        // Check cache first
        if (this.vocabularyCache.has(cacheKey)) {
            return this.vocabularyCache.get(cacheKey);
        }

        console.log(`Translating vocabulary: ${word} (${targetLang})`);

        try {
            // Step 1: Try Free Dictionary API for rich data
            const definitionData = await this.getWordDefinition(word);
            
            // Step 2: Try Google Translate for direct translation
            let translation = null;
            try {
                translation = await this.translateWithGoogle(word, 'en', targetLang);
                console.log(`Google Translate successful for vocabulary: ${word} -> ${translation}`);
            } catch (googleError) {
                console.warn(`Google Translate failed for vocabulary ${word}:`, googleError.message);
            }

            // Step 3: If Google failed, try MyMemory
            if (!translation) {
                try {
                    translation = await this.translateWithMyMemory(word, 'en', targetLang);
                    console.log(`MyMemory successful for vocabulary: ${word} -> ${translation}`);
                } catch (myMemoryError) {
                    console.warn(`MyMemory failed for vocabulary ${word}:`, myMemoryError.message);
                }
            }

            // Create result object
            const result = {
                translation: translation || `[Translation unavailable: ${word}]`,
                definition: definitionData,
                source: translation ? (translation.includes('Google') ? 'google' : 'mymemory') : 'none'
            };

            // Cache the result
            this.vocabularyCache.set(cacheKey, result);
            this.manageCacheSize(this.vocabularyCache);

            return result;

        } catch (error) {
            console.error(`Vocabulary translation error for ${word}:`, error);
            return {
                translation: `[Translation failed: ${word}]`,
                definition: null,
                source: 'error'
            };
        }
    }

    // SENTENCE TRANSLATION: MyMemory → Google Translate → Free Dictionary API (for words)
    async translateSentence(sentence, targetLang = 'zh') {
        const cacheKey = `${sentence}_${targetLang}`;
        
        // Check cache first
        if (this.sentenceCache.has(cacheKey)) {
            return this.sentenceCache.get(cacheKey);
        }

        console.log(`Translating sentence: ${sentence.substring(0, 50)}... (${targetLang})`);

        try {
            // Step 1: Try MyMemory for sentence translation
            let translation = null;
            try {
                translation = await this.translateWithMyMemory(sentence, 'en', targetLang);
                console.log(`MyMemory successful for sentence: ${sentence.substring(0, 30)}... -> ${translation.substring(0, 30)}...`);
            } catch (myMemoryError) {
                console.warn(`MyMemory failed for sentence:`, myMemoryError.message);
            }

            // Step 2: If MyMemory failed, try Google Translate
            if (!translation) {
                try {
                    translation = await this.translateWithGoogle(sentence, 'en', targetLang);
                    console.log(`Google Translate successful for sentence: ${sentence.substring(0, 30)}... -> ${translation.substring(0, 30)}...`);
                } catch (googleError) {
                    console.warn(`Google Translate failed for sentence:`, googleError.message);
                }
            }

            // Step 3: If both failed, try word-by-word translation with Free Dictionary API
            if (!translation) {
                try {
                    translation = await this.translateSentenceWordByWord(sentence, targetLang);
                    console.log(`Word-by-word translation successful for sentence`);
                } catch (wordByWordError) {
                    console.warn(`Word-by-word translation failed:`, wordByWordError.message);
                }
            }

            const result = {
                translation: translation || `[Translation unavailable: ${sentence.substring(0, 50)}...]`,
                source: translation ? (translation.includes('MyMemory') ? 'mymemory' : 
                                    translation.includes('Google') ? 'google' : 'word-by-word') : 'none'
            };

            // Cache the result
            this.sentenceCache.set(cacheKey, result);
            this.manageCacheSize(this.sentenceCache);

            return result;

        } catch (error) {
            console.error(`Sentence translation error:`, error);
            return {
                translation: `[Translation failed: ${sentence.substring(0, 50)}...]`,
                source: 'error'
            };
        }
    }

    // Free Dictionary API integration
    async getWordDefinition(word) {
        const cacheKey = `def_${word}`;
        
        if (this.definitionCache.has(cacheKey)) {
            return this.definitionCache.get(cacheKey);
        }

        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 5000);

            const response = await fetch(`${this.freeDictionaryUrl}/${encodeURIComponent(word)}`, {
                signal: controller.signal,
                headers: {
                    'Accept': 'application/json',
                    'User-Agent': 'VocabKiller/1.0'
                }
            });

            clearTimeout(timeoutId);

            if (response.ok) {
                const data = await response.json();
                if (data && data.length > 0) {
                    const wordData = data[0];
                    const definition = {
                        word: wordData.word,
                        phonetic: wordData.phonetic || wordData.phonetics?.[0]?.text || '',
                        meanings: wordData.meanings || [],
                        audio: wordData.phonetics?.find(p => p.audio)?.audio || null
                    };

                    this.definitionCache.set(cacheKey, definition);
                    this.manageCacheSize(this.definitionCache);

                    return definition;
                }
            }
        } catch (error) {
            console.warn(`Free Dictionary API failed for ${word}:`, error.message);
        }

        return null;
    }

    // Google Translate integration
    async translateWithGoogle(text, fromLang, toLang) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);

        // Handle language codes for Google Translate
        let googleLangCode = toLang;
        if (toLang === 'zh-tw') {
            googleLangCode = 'zh-TW';
        } else if (toLang === 'zh') {
            googleLangCode = 'zh-CN';
        }

        try {
            const response = await fetch(
                `${this.googleTranslateUrl}?client=gtx&sl=${fromLang}&tl=${googleLangCode}&dt=t&q=${encodeURIComponent(text)}`,
                {
                    signal: controller.signal,
                    headers: {
                        'Accept': 'application/json',
                        'User-Agent': 'VocabKiller/1.0'
                    }
                }
            );

            clearTimeout(timeoutId);

            if (response.ok) {
                const data = await response.json();
                const translation = data[0]?.[0]?.[0];
                if (translation) {
                    return translation;
                }
            }

            throw new Error(`Google Translate HTTP error: ${response.status}`);
        } catch (error) {
            clearTimeout(timeoutId);
            throw error;
        }
    }

    // MyMemory integration
    async translateWithMyMemory(text, fromLang, toLang) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);

        try {
            const langpair = `${fromLang}|${toLang}`;
            const response = await fetch(
                `${this.myMemoryUrl}?q=${encodeURIComponent(text)}&langpair=${langpair}`,
                {
                    signal: controller.signal,
                    headers: {
                        'Accept': 'application/json',
                        'User-Agent': 'VocabKiller/1.0'
                    }
                }
            );

            clearTimeout(timeoutId);

            if (response.ok) {
                const data = await response.json();
                const translation = data.responseData?.translatedText;
                if (translation && translation !== text) {
                    return translation;
                }
            }

            throw new Error(`MyMemory HTTP error: ${response.status}`);
        } catch (error) {
            clearTimeout(timeoutId);
            throw error;
        }
    }

    // Word-by-word translation using Free Dictionary API
    async translateSentenceWordByWord(sentence, targetLang) {
        // Extract words from sentence
        const words = sentence.toLowerCase().match(/\b[a-z]+\b/g) || [];
        const uniqueWords = [...new Set(words)];

        // Get translations for each word
        const wordTranslations = {};
        for (const word of uniqueWords) {
            try {
                const result = await this.translateVocabulary(word, targetLang);
                if (result.translation && !result.translation.includes('[Translation')) {
                    wordTranslations[word] = result.translation;
                }
            } catch (error) {
                console.warn(`Failed to translate word ${word}:`, error.message);
            }
        }

        // Replace words in sentence with translations
        let translatedSentence = sentence;
        Object.entries(wordTranslations).forEach(([word, translation]) => {
            const regex = new RegExp(`\\b${word}\\b`, 'gi');
            translatedSentence = translatedSentence.replace(regex, translation);
        });

        return translatedSentence;
    }

    // Clear all caches
    clearCaches() {
        this.vocabularyCache.clear();
        this.sentenceCache.clear();
        this.definitionCache.clear();
        this.initializeCommonWords(); // Re-initialize common words
        console.log('All translation caches cleared');
    }

    // Get cache statistics
    getCacheStats() {
        return {
            vocabularyCache: this.vocabularyCache.size,
            sentenceCache: this.sentenceCache.size,
            definitionCache: this.definitionCache.size,
            totalCacheSize: this.vocabularyCache.size + this.sentenceCache.size + this.definitionCache.size
        };
    }
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = UnifiedTranslationService;
}


